import React from 'react'
// import BatchComponent from '../components/Batch'
function Batch() {
  return (
    <div>

    </div>
  )
}

export default Batch
