const getCurrentDateTime =()=>{
    const currentDate = new Date();
    return currentDate.toISOString().split('T')[0] +' '+currentDate.toLocaleTimeString();
}
// console.log(getCurrentDateTime())
module.exports = {getCurrentDateTime};