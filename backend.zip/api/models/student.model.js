const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    name: {
        type: String,
        default: "",
    },
    email: {
        type: String,
        default: "",
        unique: true,
        required: true
    },
    phone: {
        type: String,
        default: "",
        unique: true,
        required: true
    },
    college: {
        type: String,
        default: "",

    },
    city: {
        type: String,
        default: "",

    },
    dob: {
        type: String,
        default: "",
        required: true,
    },
    gender: {
        type: Number,

    },
    status:{
        type: Boolean,
        default: false,
        required: true,
    },
    createdAt:{
        type: String,
        default: "",
    },
    updatedAt:{
        type: String,
        default: "",  
    }
})

const studentModel= mongoose.model('Student',studentSchema);

module.exports = studentModel;